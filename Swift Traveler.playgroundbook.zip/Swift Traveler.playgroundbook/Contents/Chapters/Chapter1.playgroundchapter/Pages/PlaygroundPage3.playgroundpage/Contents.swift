/*:

 # Let's be **tourist**!
 
 
 Grandpa - "What my granddaughter likes most about trips are the tourist attractions. I always thought it was for taking pictures... But once, she told me it was because historical monuments tell about the **history and culture** of each country. **They are a piece of the past that we can see in the present**. So how about we find out a little about them?"
 
 ## Here you will find some of the most visited monuments in the world!
 
 
 Choose one country, read about its attraction if you like to and tap on  **Sneak Peek** to see a surprise!
 
 
 ## Choose our destination and tap 'Run My Code':
 
 
 */

//#-hidden-code
import UIKit
import PlaygroundSupport


public var whereTo:Attractions = Attractions.Brazil

public func chooseCountry(local: Attractions) {
    whereTo = local
}

//#-end-hidden-code

chooseCountry(local: /*#-editable-code*/.Brazil /*#-end-editable-code*/)



//#-hidden-code

let viewController = AttractionsViewController()
viewController.thisCountry = whereTo
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
