/*:
 # First things first!
 
 
 Grandpa - "The first things we should think about before marking a trip are: where we are going, where we are staying and for how long. Even because nobody wants to stay in a distant city sleeping under a bridge, right?"
 
 ## "Therefore, I selected some **countries** for you to travel!"
 
 In each one you will be able to see the **3 main cities** of it and learn a little bit about them.
 
 Choose one country and tap on "Run My Code" to discover a little bit about its cities!
 
 ### Notice:
 
 * Some cities tell a little more about the journey of Grandpa, our guide!
 
 
 ## Choose our destination and tap 'Run My Code':
 */

//#-hidden-code
import UIKit
import PlaygroundSupport


public var whereTo:Places = Places.Portugal

public func chooseCountry(local: Places) {
    whereTo = local
}

//#-end-hidden-code

chooseCountry(local: /*#-editable-code*/.Portugal/*#-end-editable-code*/)



//#-hidden-code

let viewController = MapViewController()
viewController.thisCountry = whereTo
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
