/*:
 
 # Time to Say Goodbye...
 
 
 Grandpa - "Well, you must be very tired after travelling that much! It's was a great pleasure to share my story with you and I hope that, some day, you can tell me about **yours**! But for now, it's time for us to go separed ways..."
 
 ## Thank you!
 
 # Credits:
 
 * Globe 3D model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/49ab04106c775dcf6e8129739c25223d/Earth)
 * Big Ben model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/6fc81e2222d707079910adedd1e64f76/Big-Ben)
 * Eiffel Tower model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/9911f391c0cfff3332f69a476b3a89d0/Eiffel-Tower)
 * Redeemer model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/87c54d89f6353b94a031a22766cbfa56/Cristo-Redentor)
 * Statue of Liberty model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/ba8208b2d428d21b4e9c97ed762572a1/Statue-Of-Liberty)
 * Taj Mahal model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/aff4325304030411fb8664eff9c5b1f9/Taj-Mahal)
 * Giza Pyramids model based on [3DWarehouse](https://3dwarehouse.sketchup.com/model/76d17c638bcb4b4fcafa971dbc1c79d/Giza-Pyramids)
 * Mapa Mundi background on paged 2 based on [freepik](https://www.freepik.com/free-vector/tourists-landmarks-poster_3861854.htm#page=1&index=1&query=isometric%20world)
 * Isometric Maps on paged 2 based on [freepik](https://www.freepik.com/macrovector)
 * Mapa Mundi background on paged 3 based on [freepik](https://www.freepik.com/free-vector/tourists-landmarks-poster_3861854.htm#page=1&index=1&query=isometric%20world)
 * Flags on paged 4 based on [freepik](https://www.freepik.com/free-vector/flags-world-collection_837815.htm)
 * Airport background on paged 5 based on [freepik](https://www.freepik.com/free-vector/airport-vertical-banners_3796779.htm#page=2&index=10&query=airport)

 */
