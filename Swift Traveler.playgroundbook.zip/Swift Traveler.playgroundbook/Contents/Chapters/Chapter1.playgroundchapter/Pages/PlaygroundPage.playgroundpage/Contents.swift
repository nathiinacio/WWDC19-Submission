/*:
 # Welcome to Swift Traveler!
 
## Here we will join us in an adventure around the world!
 
  Now let's meet **Grandpa**, Nathalia's grandfather! He will be our guide in this journey!
 
 Grandpa -  "Hello, I'm Grandpa and today I will tell you a little bit of my story! I am Portuguese and I live in Brazil as an immigrant for many years. You can imagine my one way trip to Brazil as an unforgettable adventure but in fact, I went to Brazil in a basement of a codfish ship. **Sounds a bit bad, right?**
 
 Well, my goal here today is to show you a little bit about the world and the main things to know when traveling. In that way I hope that you do not go through situations like my trip."
 
 **Are you ready for this adventure?**
 
 # **Pack your bags** and come with us!
 
 **After seing where Brazil and Portugal are in the Globe, go to the [Next Page](@next)**

 ### Notice
 
 * For a better experience, I recommend you run this entire playground in a **Side by Side + Landscape** mode.
 
 * If you feel the need of using it in Fullscreen, please do it in Portrait mode.
 
  * In the Pages with AR, please be in a place with good ilumination and map it until you detect a plane to place the model.
 
 */

