//
//  GlobeViewController.swift
//  Swift Traveler
//
//  Created by Nathalia Inacio on 18/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import PlaygroundSupport

public class GlobeViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate, PlaygroundLiveViewSafeAreaContainer {
    
    public var sceneView: ARSCNView!
    public var grandpaView = UIImageView()
    public var speechBalloon = UIImageView()
    public var labelView = UIImageView()
    
    private var planeNode: SCNNode?
    private var planeColor = UIColor(red: 90/255, green: 200/255, blue: 250/255, alpha: 0.50)
    private let planeDetectorName = "plane detector"
    

    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.sceneView = ARSCNView()
        self.view = sceneView
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        
        addTapGestureToSceneView()
        
        grandpaView = UIImageView(image: UIImage(named: "Grandpa"))
        
        grandpaView.contentMode = .scaleAspectFit
        grandpaView.translatesAutoresizingMaskIntoConstraints = false
        
        speechBalloon = UIImageView(image: UIImage(named: "GlobeSpeechBalloon"))
        
        speechBalloon.contentMode = .scaleAspectFit
        speechBalloon.translatesAutoresizingMaskIntoConstraints = false
        
        labelView = UIImageView(image: UIImage(named: "GlobeLabel"))
        labelView.contentMode = .scaleAspectFill
        labelView.translatesAutoresizingMaskIntoConstraints = false
        
        
        sceneView.addSubview(grandpaView)
        sceneView.addSubview(speechBalloon)
        sceneView.addSubview(labelView)
        
        
        sceneView.clipsToBounds = true
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            sceneView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            sceneView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            sceneView.topAnchor.constraint(equalTo: self.view.topAnchor),
            sceneView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
            ])
        
        
        
    }
    
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addHorizontalPlaneDetection()
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    
    
    public func addLighting() {
        sceneView.autoenablesDefaultLighting = true
    }
    
    
    
    // MARK: - Gestures
    
    @objc func onViewTapped(withGestureRecognizer sender: UITapGestureRecognizer) {
        
        let tapLocation = sender.location(in: sceneView)
        let hits = sceneView.hitTest(tapLocation, types: .existingPlaneUsingExtent)
        if let hit = hits.first {
            placeAttraction(hit)
            disablePlaneScanning()
        }
    }
    
    public func addTapGestureToSceneView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(GlobeViewController.onViewTapped(withGestureRecognizer:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    
    // MARK: - Place Tourist Attraction
    
    public func placeAttraction(_ hit: ARHitTestResult) {
        let planePosition = calcPlanePosition(from: hit)
        addAttractionToScene(at: planePosition)
        
    }
    
    public func calcPlanePosition(from hit: ARHitTestResult) -> SCNVector3 {
        let transform = hit.worldTransform
        return SCNVector3Make(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
    }
    
    public func addAttractionToScene(at position: SCNVector3) {
        if let attractionNode = createAttractionFromScene(at: position) {
            sceneView.scene.rootNode.addChildNode(attractionNode)
        } else {
            alertError(title: "Error creating attraction from scene")
        }
    }
    
    public func createAttractionFromScene(at position: SCNVector3) -> SCNNode? {
        
        guard let url = Bundle.main.url(forResource: "World", withExtension: "scn", subdirectory: "art.scnassets") else {
            alertError(title: "Error finding attraction scene")
            return nil
        }
        
        guard let attractionScene = SCNReferenceNode(url: url) else {
            alertError(title: "Error loading attraction scene")
            return nil
        }
        
        attractionScene.load()
        attractionScene.position = position
        return attractionScene
        
        
        
        
    }
    
    // MARK: - Plane Detection
    
    public func addHorizontalPlaneDetection() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
        sceneView.debugOptions = [SCNDebugOptions.showFeaturePoints]
    }
    
    public func disablePlaneScanning() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = []
        sceneView.session.run(configuration)
        sceneView.scene.rootNode.enumerateChildNodes() {
            node, stop in
            if node.name == planeDetectorName {
                node.removeFromParentNode()
                self.sceneView.debugOptions = []
                
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        // Create an SCNNode for a detect ARPlaneAnchor
        guard let _ = anchor as? ARPlaneAnchor else {
            return nil
        }
        planeNode = SCNNode()
        return planeNode
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else {
            return
        }
        let plane = SCNPlane(width: CGFloat(planeAnchor.extent.x), height: CGFloat(planeAnchor.extent.z))
        
        let planeMaterial = SCNMaterial()
        planeMaterial.diffuse.contents = planeColor
        plane.firstMaterial = planeMaterial
        
        let planeNode = SCNNode(geometry: plane)
        planeNode.name = planeDetectorName
        planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
        
        planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2, 1, 0, 0)
        
        node.addChildNode(planeNode)
    }
    
    // MARK: - Error Handling
    
    public func alertError(title: String) {
        let message = "Please try restarting the app"
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    public override func viewDidLayoutSubviews() {
        
        ///Landscape
        if view.frame.width > view.frame.height {
            
            grandpaView.frame.size.width = (403.0/1024) * view.frame.width
            grandpaView.frame.size.height = (693.0 / 1024) * view.frame.width
            grandpaView.center.x = (823.0/1024) * view.frame.width
            grandpaView.center.y = (1259.0/1366) * view.frame.width
            
            speechBalloon.frame.size.width = (390.0/1024) * view.frame.width
            speechBalloon.frame.size.height = (364.0 / 1024) * view.frame.width
            speechBalloon.center.x = (809.0/1024) * view.frame.width
            speechBalloon.center.y = (776.0/1366) * view.frame.width
            
            labelView.frame.size.width = (421.0/1024) * view.frame.width
            labelView.frame.size.height = (124.0 / 1024) * view.frame.width
            labelView.center.x = (281.0/1024) * view.frame.width
            labelView.center.y = (380.0/1366) * view.frame.width
            
        }
            ///Portrait
        else {
            
            grandpaView.frame.size.width = (403.0/1366) * (view.frame.height)
            grandpaView.frame.size.height = (693.0/1366) * view.frame.height
            grandpaView.center.x = (823.0/1024) * view.frame.width
            grandpaView.center.y = (1259.0/1366) * view.frame.height
            
            speechBalloon.frame.size.width = (390.0/1366) * (view.frame.height)
            speechBalloon.frame.size.height = (364.0/1366) * view.frame.height
            speechBalloon.center.x = (809.0/1024) * view.frame.width
            speechBalloon.center.y = (776.0/1366) * view.frame.height
            
            labelView.frame.size.width = (421.0/1024) * view.frame.width
            labelView.frame.size.height = (124.0 / 1024) * view.frame.width
            labelView.center.x = (281.0/1024) * view.frame.width
            labelView.center.y = (380.0/1366) * view.frame.width
            
            
        }
        
        super.viewDidLayoutSubviews()
    }
    
}
