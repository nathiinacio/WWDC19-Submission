//
//  MapDefaultViewController.swift
//  Book_Sources
//
//  Created by Nathalia Inacio on 23/03/19.
//


import UIKit
import PlaygroundSupport

public class MapDefaultViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    public var newView = UIImageView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        newView = UIImageView(image: UIImage(named: "CitiesMap"))
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
       
        
        
        view.addSubview(newView)
    
        
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
}

}
