//
//  Attractions.swift
//  Book_Sources
//
//  Created by Nathalia Inacio on 22/03/19.
//

import Foundation


public enum Attractions: String {
    case Brazil = "Brazil"
    case USA = "USA"
    case France = "France"
    case Italy = "Italy"
    case Egypt = "Egypt"
    case UK = "UK"
    case India = "India"
}
