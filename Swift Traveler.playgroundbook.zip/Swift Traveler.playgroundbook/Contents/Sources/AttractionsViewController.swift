//
//  ViewController.swift
//  Swift Traveler
//
//  Created by Nathalia Inacio on 17/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//


import UIKit
import SceneKit
import ARKit
import PlaygroundSupport

public class AttractionsViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewSafeAreaContainer {
    
    
    public var sceneView: ARSCNView = ARSCNView()
    public var newView = UIImageView()

    public var sneakPeekButton = UIButton()
    
    
    public var countryManager:CountryManager?
    public var thisCountry: Attractions?
    
    
    // MARK: - Controller Lifecycle
    
    public override func viewDidLoad() {
        
        let countryName = thisCountry?.rawValue ?? Attractions.Brazil.rawValue
        self.countryManager = CountryManager(country: countryName)
        
        super.viewDidLoad()
    
 
        newView = UIImageView(image: UIImage(named: (countryManager?.atrractionName)!))
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
        sneakPeekButton.setImage(UIImage(named: "SneakPeekButton"), for: .normal)
        sneakPeekButton.addTarget(self, action: #selector(viewAR), for: .touchUpInside)
        sneakPeekButton.contentMode = .center
        sneakPeekButton.contentMode = .scaleAspectFit
        sneakPeekButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(newView)
        view.addSubview(sneakPeekButton)
        
        pulsate()
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        

        
    }
    
    public func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.6
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 200
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        sneakPeekButton.layer.add(pulse, forKey: "pulseAnimation")
    
    }
    
    
    @objc public func viewAR(sender: UIButton!) {
    
        guard let country = self.thisCountry else {return}
        self.present(ARView(coutry: country), animated: false, completion: nil)
        
    }
    

    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    
    public override func viewDidLayoutSubviews() {
        
        ///Landscape
        if view.frame.width > view.frame.height {
            
            sneakPeekButton.frame.size.width = (332.0/1024) * view.frame.width
            sneakPeekButton.frame.size.height = (126.0 / 1024) * view.frame.width
            sneakPeekButton.center.x = (722.0/1024) * view.frame.width
            sneakPeekButton.center.y = (1060.0/1366) * view.frame.width
        
            
            if countryManager?.atrractionName == "TajMahal"{
                sneakPeekButton.frame.size.width = (332.0/1024) * view.frame.width
                sneakPeekButton.frame.size.height = (126.0 / 1024) * view.frame.width
                sneakPeekButton.center.x = (795.0/1024) * view.frame.width
                sneakPeekButton.center.y = (883.0/1366) * view.frame.height
            }
            
            
        }
            ///Portrait
        else {
            
            sneakPeekButton.frame.size.width = (332.0/1024) * view.frame.width
            sneakPeekButton.frame.size.height = (126.0 / 1024) * view.frame.width
            sneakPeekButton.center.x = (722.0/1024) * view.frame.width
            sneakPeekButton.center.y = (1060.0/1366) * view.frame.height
            
            
            
            if countryManager?.atrractionName == "TajMahal"{
                sneakPeekButton.frame.size.width = (332.0/1024) * view.frame.width
                sneakPeekButton.frame.size.height = (126.0 / 1024) * view.frame.width
                sneakPeekButton.center.x = (795.0/1024) * view.frame.width
                sneakPeekButton.center.y = (883.0/1366) * view.frame.height
            }
            
        }
        
        super.viewDidLayoutSubviews()
    }

    
    
}


