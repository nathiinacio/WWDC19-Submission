//
//  CulinaryViewController.swift
//  Swift Traveler
//
//  Created by Nathalia Inacio on 20/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//

import Foundation
import UIKit
import PlaygroundSupport

public class CulinaryViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    
    public var newViewsArray: [UIImageView] = []
    public var newView = UIImageView()
    public var grandpaView = UIImageView()
    public var speechBallon = UIImageView()
    public var indexPath = Int()
    
    public var flagButton1 = UIButton()
    public var flagButton2 = UIButton()
    public var flagButton3 = UIButton()
    public var tryAgainButton = UIButton()
    public var whichCountry = String()
    
    public var score = Int()
    
    override public func viewDidLoad() {
        
        
        score = 0
        indexPath = 0
        
        view.translatesAutoresizingMaskIntoConstraints = false
        
        
        
        grandpaView = UIImageView(image: UIImage(named: "Grandpa"))
        
        grandpaView.contentMode = .scaleAspectFit
        grandpaView.translatesAutoresizingMaskIntoConstraints = false
        
        speechBallon = UIImageView(image: UIImage(named: "CulinarySpeechBalloon"))
        
        speechBallon.contentMode = .scaleAspectFit
        speechBallon.translatesAutoresizingMaskIntoConstraints = false
        
        newViewsArray = [UIImageView(image: UIImage(named: "Cheeseburger")),UIImageView(image: UIImage(named: "Tiramisu")), UIImageView(image: UIImage(named: "GreenBroth")), UIImageView(image: UIImage(named: "ChickenCurry")), UIImageView(image: UIImage(named: "Macaron")), UIImageView(image: UIImage(named: "FishAndChips")), UIImageView(image: UIImage(named: "Brigadeiro")), UIImageView(image: UIImage(named: "Falafel"))]
        
        
        
        newView = newViewsArray[indexPath]
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
        
        flagButton1.addTarget(self, action: #selector(checkFlag1), for: .touchUpInside)
        flagButton1.contentMode = .center
        flagButton1.contentMode = .scaleAspectFit
        flagButton1.translatesAutoresizingMaskIntoConstraints = false
        
        
        flagButton2.addTarget(self, action: #selector(checkFlag2), for: .touchUpInside)
        flagButton2.contentMode = .center
        flagButton2.contentMode = .scaleAspectFit
        flagButton2.translatesAutoresizingMaskIntoConstraints = false
        
        
        flagButton3.addTarget(self, action: #selector(checkFlag3), for: .touchUpInside)
        flagButton3.contentMode = .center
        flagButton3.contentMode = .scaleAspectFit
        flagButton3.translatesAutoresizingMaskIntoConstraints = false
        
        
        tryAgainButton.addTarget(self, action: #selector(tryAgain), for: .touchUpInside)
        tryAgainButton.setImage(UIImage(named: "TryAgainButton"), for: .normal)
        tryAgainButton.contentMode = .center
        tryAgainButton.contentMode = .scaleAspectFit
        tryAgainButton.translatesAutoresizingMaskIntoConstraints = false
        
        
        getCountry()
        pulsate()
        
        view.addSubview(newView)
        view.addSubview(grandpaView)
        view.addSubview(speechBallon)
        view.addSubview(flagButton1)
        view.addSubview(flagButton2)
        view.addSubview(flagButton3)
        
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
        
    }
    
    public func getCountry(){
        
        
        if newViewsArray[indexPath].image == UIImage(named: "GreenBroth"){
            
            whichCountry = "Portugal"
            
            let theCountry = CountryManager(country: whichCountry)
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
        } else if newViewsArray[indexPath].image == UIImage(named: "Tiramisu"){
            
            whichCountry = "Italy"
            
            let theCountry = CountryManager(country: whichCountry)
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
            
        } else if newViewsArray[indexPath].image == UIImage(named: "Macaron"){
            
            whichCountry = "France"
            
            let theCountry = CountryManager(country: whichCountry)
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
        } else if newViewsArray[indexPath].image == UIImage(named: "Falafel"){
            
            whichCountry = "Egypt"
            
            let theCountry = CountryManager(country: whichCountry)
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
            
        } else if newViewsArray[indexPath].image == UIImage(named: "Cheeseburger"){
            
            whichCountry = "USA"
            
            let theCountry = CountryManager(country: whichCountry)
            
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
        } else if newViewsArray[indexPath].image == UIImage(named: "ChickenCurry"){
            
            whichCountry = "India"
            
            let theCountry = CountryManager(country: whichCountry)
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
        } else if newViewsArray[indexPath].image == UIImage(named: "FishAndChips"){
            
            whichCountry = "UK"
            
            let theCountry = CountryManager(country: whichCountry)
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
        } else if newViewsArray[indexPath].image == UIImage(named: "Brigadeiro"){
            
            whichCountry = "Brazil"
            
            let theCountry = CountryManager(country: whichCountry)
            
            
            flagButton1.setImage(UIImage(named: theCountry.flag1Name!), for: .normal)
            flagButton2.setImage(UIImage(named: theCountry.flag2Name!), for: .normal)
            flagButton3.setImage(UIImage(named: theCountry.flag3Name!), for: .normal)
            
            
        } else{}
        
    }
    
    
    public func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.6
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 200
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        flagButton1.layer.add(pulse, forKey: "pulseAnimation")
        flagButton2.layer.add(pulse, forKey: "pulseAnimation")
        flagButton3.layer.add(pulse, forKey: "pulseAnimation")
        tryAgainButton.layer.add(pulse, forKey: "pulseAnimation")
    }
    
    
    
    
    
    
    @objc func tryAgain(sender: UIButton!){
        
        indexPath = 0
        newView = newViewsArray[indexPath]
        view.addSubview(newView)
        speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
        getCountry()
        pulsate()
        
        view.bringSubviewToFront(grandpaView)
        view.bringSubviewToFront(speechBallon)
        
        view.addSubview(flagButton1)
        view.addSubview(flagButton2)
        view.addSubview(flagButton3)
        
        flagButton1.alpha = 1
        flagButton1.isEnabled = true
        flagButton2.alpha = 1
        flagButton2.isEnabled = true
        flagButton3.alpha = 1
        flagButton3.isEnabled = true
        
        tryAgainButton.alpha = 0
        tryAgainButton.isEnabled = false
        
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
    }
    
    
    func foward() {
        
        indexPath = indexPath + 1
        newView = newViewsArray[indexPath]
        view.addSubview(newView)
        speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
        getCountry()
        pulsate()
        
        view.bringSubviewToFront(grandpaView)
        view.bringSubviewToFront(speechBallon)
        view.addSubview(flagButton1)
        view.addSubview(flagButton2)
        view.addSubview(flagButton3)
        
        
        
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
        
    }
    
    
    
    @objc func checkFlag1(sender: UIButton!) {
        
        let theCountry = CountryManager(country: whichCountry)
        
        if whichCountry == theCountry.flag1Name
        {
            score = score + 1
            speechBallon.image = UIImage(named: "RightBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
            
            
        }
            
        else
        {
            speechBallon.image = UIImage(named: "WrongBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
        }
        
    }
    
    
    @objc func checkFlag2(sender: UIButton!) {
        
        let theCountry = CountryManager(country: whichCountry)
        
        if whichCountry == theCountry.flag2Name
        {
            score = score + 1
            speechBallon.image = UIImage(named: "RightBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
            
        }
            
        else
        {
            speechBallon.image = UIImage(named: "WrongBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
        }
        
    }
    
    @objc func checkFlag3(sender: UIButton!) {
        
        let theCountry = CountryManager(country: whichCountry)
        
        if whichCountry == theCountry.flag3Name
        {
            score = score + 1
            speechBallon.image = UIImage(named: "RightBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
        }
            
        else
        {
            speechBallon.image = UIImage(named: "WrongBalloon")
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.speechBallon.image = UIImage(named: "CulinarySpeechBalloon")
                if self.indexPath != 7{
                    self.foward()
                    
                }
                else{
                    
                    if self.score == 1{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results1"))
                        
                    }else if self.score == 2 {
                        
                        self.newView = UIImageView(image: UIImage(named: "Results2"))
                        
                    }else if self.score == 3{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results3"))
                        
                    }else if self.score == 4{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results4"))
                        
                    }else if self.score == 5{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results5"))
                        
                    }else if self.score == 6{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results6"))
                        
                    }else if self.score == 7{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results7"))
                        
                    }else if self.score == 8{
                        
                        self.newView = UIImageView(image: UIImage(named: "Results8"))
                        
                    }else{}
                    
                    
                    self.view.addSubview(self.newView)
                    self.speechBallon.image = UIImage(named: "ResultsSpeechBalloon")
                    
                    self.view.bringSubviewToFront(self.grandpaView)
                    self.view.bringSubviewToFront(self.speechBallon)
                    self.view.addSubview(self.tryAgainButton)
                    self.pulsate()
                    
                    self.tryAgainButton.alpha = 1
                    self.tryAgainButton.isEnabled = true
                    
                    self.flagButton1.alpha = 0
                    self.flagButton1.isEnabled = false
                    self.flagButton2.alpha = 0
                    self.flagButton2.isEnabled = false
                    self.flagButton3.alpha = 0
                    self.flagButton3.isEnabled = false
                    
                    self.newView.contentMode = .scaleAspectFill
                    self.newView.translatesAutoresizingMaskIntoConstraints = false
                    
                    NSLayoutConstraint.activate([
                        self.newView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                        self.newView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
                        self.newView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
                        self.newView.heightAnchor.constraint(equalTo: self.view.heightAnchor)
                        ])
                    
                }
            })
        }
        
    }
    
    
    public override func viewDidLayoutSubviews() {
        
        if view.frame.width > view.frame.height {
            grandpaView.frame.size.width = (199.0/1024) * view.frame.width
            grandpaView.frame.size.height = (346.0 / 1024) * view.frame.width
            grandpaView.center.x = (333.0/1024) * view.frame.width
            grandpaView.center.y = (942.0/1366) * view.frame.width
            
            speechBallon.frame.size.width = (300.0/1024) * view.frame.width
            speechBallon.frame.size.height = (200.0 / 1024) * view.frame.width
            speechBallon.center.x = (339.0/1024) * view.frame.width
            speechBallon.center.y = (615.0/1366) * view.frame.width
            
            flagButton1.frame.size.width = (100.0/1024) * view.frame.width
            flagButton1.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton1.center.x = (498.0/1024) * view.frame.width
            flagButton1.center.y = (1090.0/1366) * view.frame.width
            
            flagButton2.frame.size.width = (100.0/1024) * view.frame.width
            flagButton2.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton2.center.x = (625.0/1024) * view.frame.width
            flagButton2.center.y = (1090.0/1366) * view.frame.width
            
            flagButton3.frame.size.width = (100.0/1024) * view.frame.width
            flagButton3.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton3.center.x = (752.0/1024) * view.frame.width
            flagButton3.center.y = (1090.0/1366) * view.frame.width
            
            tryAgainButton.frame.size.width = (292.0/1024) * view.frame.width
            tryAgainButton.frame.size.height = (103.0 / 1024) * view.frame.width
            tryAgainButton.center.x = (620.0/1024) * view.frame.width
            tryAgainButton.center.y = (1064.0/1366) * view.frame.width
            
        }
            ///Portrait
        else {
            grandpaView.frame.size.width = (199.0/1366) * (view.frame.height)
            grandpaView.frame.size.height = (346.0/1366) * view.frame.height
            grandpaView.center.x = (333.0/1024) * view.frame.width
            grandpaView.center.y = (942.0/1366) * view.frame.height
            
            speechBallon.frame.size.width = (213.0/1366) * (view.frame.height)
            speechBallon.frame.size.height = (190.0/1366) * view.frame.height
            speechBallon.center.x = (337.0/1024) * view.frame.width
            speechBallon.center.y = (698.0/1366) * view.frame.height
            
            flagButton1.frame.size.width = (100.0/1024) * view.frame.width
            flagButton1.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton1.center.x = (498.0/1024) * view.frame.width
            flagButton1.center.y = (1090.0/1366) * view.frame.height
            
            flagButton2.frame.size.width = (100.0/1024) * view.frame.width
            flagButton2.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton2.center.x = (625.0/1024) * view.frame.width
            flagButton2.center.y = (1090.0/1366) * view.frame.height
            
            flagButton3.frame.size.width = (100.0/1024) * view.frame.width
            flagButton3.frame.size.height = (100.0 / 1024) * view.frame.width
            flagButton3.center.x = (752.0/1024) * view.frame.width
            flagButton3.center.y = (1090.0/1366) * view.frame.height
            
            tryAgainButton.frame.size.width = (292.0/1024) * view.frame.width
            tryAgainButton.frame.size.height = (103.0 / 1024) * view.frame.width
            tryAgainButton.center.x = (620.0/1024) * view.frame.width
            tryAgainButton.center.y = (1064.0/1366) * view.frame.height
            
        }
        
        super.viewDidLayoutSubviews()
    }
    
}
