//
//  ViewController.swift
//  Swift Traveler
//
//  Created by Nathalia Inacio on 17/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//


import UIKit
import SceneKit
import ARKit
import PlaygroundSupport

public class ARView: UIViewController, ARSCNViewDelegate, ARSessionDelegate, PlaygroundLiveViewSafeAreaContainer {
    
    public var labelView = UIImageView()
    
    public var sceneView: ARSCNView!

    public var closeButton = UIButton()
    
    private var planeNode: SCNNode?
    private var planeColor = UIColor(red: 90/255, green: 200/255, blue: 250/255, alpha: 0.50)
    private let planeDetectorName = "plane detector"
    
    public var countryManager:CountryManager?
    public var thisCountry: Attractions
    

    
    // MARK: - Controller Lifecycle
    
    public init(coutry: Attractions) {
        self.thisCountry = coutry
        super.init(nibName: nil, bundle: nil)
        let countryName = thisCountry.rawValue
        self.countryManager = CountryManager(country: countryName)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        self.sceneView = ARSCNView()
        self.view = sceneView
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        addTapGestureToSceneView()
        
        labelView = UIImageView(image: UIImage(named: "AttractionLabel"))
        labelView.contentMode = .scaleAspectFill
    labelView.translatesAutoresizingMaskIntoConstraints = false
        

        closeButton.addTarget(self, action: #selector(closeAR), for: .touchUpInside)
        closeButton.setImage(UIImage(named: "CloseButton"), for: .normal)
        closeButton.contentMode = .center
        closeButton.contentMode = .scaleAspectFit
        closeButton.translatesAutoresizingMaskIntoConstraints = false

        sceneView.addSubview(closeButton)
        sceneView.addSubview(labelView)

        pulsate()
        
        
    }
    
    public func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.6
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 200
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
     
        closeButton.layer.add(pulse, forKey: "pulseAnimation")
        
    }
    
    

    
    @objc public func closeAR(sender: UIButton!) {
        
       self.dismiss(animated: true, completion: nil)
        
    }
    
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addHorizontalPlaneDetection()
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    

    
    public func addLighting() {
        sceneView.autoenablesDefaultLighting = true
    }
    
    
    
    // MARK: - Gestures
    
    @objc func onViewTapped(withGestureRecognizer sender: UITapGestureRecognizer) {
        
        let tapLocation = sender.location(in: sceneView)
        let hits = sceneView.hitTest(tapLocation, types: .existingPlaneUsingExtent)
        if let hit = hits.first {
            placeAttraction(hit)
            disablePlaneScanning()
           
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3), execute: {
                
            PlaygroundPage.current.assessmentStatus = .pass(message: "You already discovered a **tourist point**. Have you traveled much around the countries? Go to the [**Next Page**](@next)!")
    
            })
        }
    }
    
    public func addTapGestureToSceneView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ARView.onViewTapped(withGestureRecognizer:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    
    // MARK: - Place Tourist Attraction
    
    public func placeAttraction(_ hit: ARHitTestResult) {
        let planePosition = calcPlanePosition(from: hit)
        addAttractionToScene(at: planePosition)
    }
    
    public func calcPlanePosition(from hit: ARHitTestResult) -> SCNVector3 {
        let transform = hit.worldTransform
        return SCNVector3Make(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
    }
    
    public func addAttractionToScene(at position: SCNVector3) {
        if let attractionNode = createAttractionFromScene(at: position) {
            sceneView.scene.rootNode.addChildNode(attractionNode)
        } else {
            alertError(title: "Error creating attraction from scene")
        }
    }
    
    public func createAttractionFromScene(at position: SCNVector3) -> SCNNode? {
        
        guard let attraction = countryManager?.atrractionName else {
            fatalError("no attractionName")
        }
        
        let resource = "\(attraction)/\(attraction)"

        
            guard let url = Bundle.main.url(forResource: resource, withExtension: "scn", subdirectory: "art.scnassets") else {
                alertError(title: "Error finding attraction scene")
                return nil
            }
            
            guard let attractionScene = SCNReferenceNode(url: url) else {
                alertError(title: "Error loading attraction scene")
                return nil
            }
            
            attractionScene.load()
            attractionScene.position = position
            return attractionScene
            
        

  
    }
    
    // MARK: - Plane Detection
    
    public func addHorizontalPlaneDetection() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
        sceneView.debugOptions = [SCNDebugOptions.showFeaturePoints]
    }
    
    public func disablePlaneScanning() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = []
        sceneView.session.run(configuration)
        sceneView.scene.rootNode.enumerateChildNodes() {
            node, stop in
            if node.name == planeDetectorName {
                node.removeFromParentNode()
                self.sceneView.debugOptions = []
                
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        // Create an SCNNode for a detect ARPlaneAnchor
        guard let _ = anchor as? ARPlaneAnchor else {
            return nil
        }
        planeNode = SCNNode()
        return planeNode
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else {
            return
        }
        let plane = SCNPlane(width: CGFloat(planeAnchor.extent.x), height: CGFloat(planeAnchor.extent.z))
        
        let planeMaterial = SCNMaterial()
        planeMaterial.diffuse.contents = planeColor
        plane.firstMaterial = planeMaterial
        
        let planeNode = SCNNode(geometry: plane)
        planeNode.name = planeDetectorName
        planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
        
        planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2, 1, 0, 0)
        
        node.addChildNode(planeNode)
    }
    
    // MARK: - Error Handling
    
    public func alertError(title: String) {
        let message = "Please try restarting the app"
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    public override func viewDidLayoutSubviews() {
        
        ///Landscape
        if view.frame.width > view.frame.height {
            
           
            
            closeButton.frame.size.width = (93.0/1024) * view.frame.width
            closeButton.frame.size.height = (93.0 / 1024) * view.frame.width
            closeButton.center.x = (117.0/1024) * view.frame.width
            closeButton.center.y = (137.0/1366) * view.frame.width
            
            labelView.frame.size.width = (421.0/1024) * view.frame.width
            labelView.frame.size.height = (124.0 / 1024) * view.frame.width
            labelView.center.x = (281.0/1024) * view.frame.width
            labelView.center.y = (380.0/1366) * view.frame.width
      
            
        }
            ///Portrait
        else {
            
           
            closeButton.frame.size.width = (93.0/1024) * view.frame.width
            closeButton.frame.size.height = (93.0 / 1024) * view.frame.width
            closeButton.center.x = (117.0/1024) * view.frame.width
            closeButton.center.y = (137.0/1366) * view.frame.width
            
            
            labelView.frame.size.width = (421.0/1024) * view.frame.width
            labelView.frame.size.height = (124.0 / 1024) * view.frame.width
            labelView.center.x = (281.0/1024) * view.frame.width
            labelView.center.y = (380.0/1366) * view.frame.width
            
            
        }
        
        super.viewDidLayoutSubviews()
    }
    
    
    
}


