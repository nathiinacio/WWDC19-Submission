//
//  ViewController.swift
//  MapTest
//
//  Created by Nathalia Inacio on 21/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//

import UIKit
import PlaygroundSupport

public class MapViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {

    public var newView = UIImageView()
    public var postcardView = UIImageView()
    public var blurView = UIVisualEffectView()
    public var closeButton = UIButton()
    public var city1 = UIButton()
    public var city2 = UIButton()
    public var city3 = UIButton()
    
    public var grandpaView = UIImageView()
    
    public var speechBalloon = UIImageView()

    
    public var countryManager:CountryManager?
    public var thisCountry: Places?
    
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        let countryName = thisCountry?.rawValue ?? Places.Portugal.rawValue
        
        view.translatesAutoresizingMaskIntoConstraints = false
        
        
        self.countryManager = CountryManager(country: countryName)
        
        newView = UIImageView(image: UIImage(named: countryManager!.mapPhoto!))
        newView.contentMode = .scaleAspectFill
        newView.translatesAutoresizingMaskIntoConstraints = false
        
        
        grandpaView = UIImageView(image: UIImage(named: "Grandpa"))
        
        grandpaView.contentMode = .scaleAspectFit
        grandpaView.translatesAutoresizingMaskIntoConstraints = false
        
        
        
        speechBalloon.contentMode = .scaleAspectFit
        speechBalloon.translatesAutoresizingMaskIntoConstraints = false
        
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.light)
        blurView = UIVisualEffectView(effect: blurEffect)
        blurView.contentMode = .scaleAspectFill
        blurView.translatesAutoresizingMaskIntoConstraints = false
        
        city1.addTarget(self, action: #selector(clickPin1), for: .touchUpInside)
        city1.setImage(UIImage(named: countryManager!.pin1Color!), for: .normal)
        city1.contentMode = .center
        city1.contentMode = .scaleAspectFit
        city1.translatesAutoresizingMaskIntoConstraints = false
        
        city2.addTarget(self, action: #selector(clickPin2), for: .touchUpInside)
        city2.setImage(UIImage(named: countryManager!.pin2Color!), for: .normal)
        city2.contentMode = .center
        city2.contentMode = .scaleAspectFit
        city2.translatesAutoresizingMaskIntoConstraints = false
        
        city3.addTarget(self, action: #selector(clickPin3), for: .touchUpInside)
        city3.setImage(UIImage(named: countryManager!.pin3Color!), for: .normal)
        city3.contentMode = .center
        city3.contentMode = .scaleAspectFit
        city3.translatesAutoresizingMaskIntoConstraints = false
        
        closeButton.addTarget(self, action: #selector(clickCloseButton), for: .touchUpInside)
        closeButton.setImage(UIImage(named: "CloseButton"), for: .normal)
        closeButton.contentMode = .center
        closeButton.contentMode = .scaleAspectFit
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        
        
        pulsate()
        
        
        view.addSubview(newView)
        view.addSubview(city1)
        view.addSubview(city2)
        view.addSubview(city3)
        
        
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
    }
    
   public func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.6
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 200
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        
        city1.layer.add(pulse, forKey: "pulseAnimation")
        city2.layer.add(pulse, forKey: "pulseAnimation")
        city3.layer.add(pulse, forKey: "pulseAnimation")
        closeButton.layer.add(pulse, forKey: "pulseAnimation")
        
    }
    
    
    
    @objc public func clickPin1(sender: UIButton!){
        
        postcardView = UIImageView(image: UIImage(named: countryManager!.pin1City!))
        postcardView.contentMode = .scaleAspectFill
        postcardView.translatesAutoresizingMaskIntoConstraints = false
        
        
        view.addSubview(blurView)
        view.bringSubviewToFront(blurView)
        view.addSubview(postcardView)
        view.bringSubviewToFront(postcardView)
        view.addSubview(closeButton)
        view.bringSubviewToFront(closeButton)
        
        pulsate()
        
        
        NSLayoutConstraint.activate([
            blurView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            blurView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            blurView.widthAnchor.constraint(equalTo: view.widthAnchor),
            blurView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
    }
    
    
    
    @objc public func clickPin2(sender: UIButton!){
        
        postcardView = UIImageView(image: UIImage(named: countryManager!.pin2City!))
        postcardView.contentMode = .scaleAspectFill
        postcardView.translatesAutoresizingMaskIntoConstraints = false
        
        if countryManager!.pin2City! == "Aveiro"{
            
            speechBalloon = UIImageView(image: UIImage(named: "AveiroBalloon"))
            
            view.addSubview(blurView)
            view.bringSubviewToFront(blurView)
            view.addSubview(grandpaView)
            view.addSubview(speechBalloon)

        } else if countryManager!.pin2City! == "RiodeJaneiro"{
            
            speechBalloon = UIImageView(image: UIImage(named: "RioBalloon"))
            
            view.addSubview(blurView)
            view.bringSubviewToFront(blurView)
            view.addSubview(grandpaView)
            view.addSubview(speechBalloon)
            
        }
        
        else{
            
            view.addSubview(blurView)
            view.bringSubviewToFront(blurView)
        }

        view.addSubview(postcardView)
        view.bringSubviewToFront(postcardView)
        view.addSubview(closeButton)
        view.bringSubviewToFront(closeButton)
        
        pulsate()
        
        NSLayoutConstraint.activate([
            blurView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            blurView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            blurView.widthAnchor.constraint(equalTo: view.widthAnchor),
            blurView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
    }
    
    
    
    @objc public func clickPin3(sender: UIButton!){
        
        postcardView = UIImageView(image: UIImage(named: countryManager!.pin3City!))
        postcardView.contentMode = .scaleAspectFill
        postcardView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(blurView)
        view.bringSubviewToFront(blurView)
        view.addSubview(postcardView)
        view.bringSubviewToFront(postcardView)
        view.addSubview(closeButton)
        view.bringSubviewToFront(closeButton)
        
        pulsate()
        
        
        NSLayoutConstraint.activate([
            blurView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            blurView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            blurView.widthAnchor.constraint(equalTo: view.widthAnchor),
            blurView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
        
    }
    
    
    
    @objc public func clickCloseButton(sender: UIButton!){
        
       
        
        view.sendSubviewToBack(postcardView)
        view.sendSubviewToBack(closeButton)
        view.sendSubviewToBack(grandpaView)
        view.sendSubviewToBack(speechBalloon)
        view.sendSubviewToBack(blurView)
        view.bringSubviewToFront(newView)
        view.bringSubviewToFront(city3)
        view.bringSubviewToFront(city2)
        view.bringSubviewToFront(city1)
        pulsate()
    
        PlaygroundPage.current.assessmentStatus = .pass(message: "You already discovered a **city**. Have you traveled much around the countries? Go to the [**Next Page**](@next)!")
    }
    
    
    public override func viewDidLayoutSubviews() {
        
        ///Landscape
        if view.frame.width > view.frame.height {
            
            if countryManager!.mapPhoto! == "PortugalMap" {
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (463.0/1024) * view.frame.width
                city1.center.y = (399.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (564.0/1024) * view.frame.width
                city2.center.y = (437.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (688.0/1024) * view.frame.width
                city3.center.y = (334.0/1366) * view.frame.width - 200
                
            } else if countryManager!.mapPhoto! == "USAMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (295.0/1024) * view.frame.width
                city1.center.y = (390.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (492.0/1024) * view.frame.width
                city2.center.y = (370.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (833.0/1024) * view.frame.width
                city3.center.y = (500.0/1366) * view.frame.width - 200
  
            } else if countryManager!.mapPhoto! == "UKMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (800.0/1024) * view.frame.width
                city1.center.y = (485.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (601.0/1024) * view.frame.width
                city2.center.y = (579.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (466.0/1024) * view.frame.width
                city3.center.y = (696.0/1366) * view.frame.width - 200
                
            } else if countryManager!.mapPhoto! == "ItalyMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (431.0/1024) * view.frame.width
                city1.center.y = (362.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (430.0/1024) * view.frame.width
                city2.center.y = (566.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (833.0/1024) * view.frame.width
                city3.center.y = (801.0/1366) * view.frame.width - 200
                
                
            } else if countryManager!.mapPhoto! == "FranceMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (672.0/1024) * view.frame.width
                city1.center.y = (318.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (849.0/1024) * view.frame.width
                city2.center.y = (550.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (494.0/1024) * view.frame.width
                city3.center.y = (720.0/1366) * view.frame.width - 200
    
            } else if countryManager!.mapPhoto! == "EgyptMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (527.0/1024) * view.frame.width
                city1.center.y = (250.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (890.0/1024) * view.frame.width
                city2.center.y = (550.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (413.0/1024) * view.frame.width
                city3.center.y = (700.0/1366) * view.frame.width - 200
                
            } else if countryManager!.mapPhoto! == "BrazilMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (550.0/1024) * view.frame.width
                city1.center.y = (600.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (518.0/1024) * view.frame.width
                city2.center.y = (850.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (417.0/1024) * view.frame.width
                city3.center.y = (900.0/1366) * view.frame.width - 200
       
            } else if countryManager!.mapPhoto! == "IndiaMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (378.0/1024) * view.frame.width
                city1.center.y = (309.0/1366) * view.frame.width - 200
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (500.0/1024) * view.frame.width
                city2.center.y = (300.0/1366) * view.frame.width - 200
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (199.0/1024) * view.frame.width
                city3.center.y = (513.0/1366) * view.frame.width - 200
                
                
            }
            
            
            postcardView.frame.size.width = (1024.0/1024) * view.frame.width
            postcardView.frame.size.height = (712.0 / 1024) * view.frame.width
            postcardView.center.x = (512.0/1024) * view.frame.width
            postcardView.center.y = (741.0/1366) * view.frame.width
            
            closeButton.frame.size.width = (72.0/1024) * view.frame.width
            closeButton.frame.size.height = (72.0 / 1024) * view.frame.width
            closeButton.center.x = (86.0/1024) * view.frame.width
            closeButton.center.y = (467.0/1366) * view.frame.height
            
            grandpaView.frame.size.width = (398.0/1024) * view.frame.width
            grandpaView.frame.size.height = (648.0 / 1024) * view.frame.width
            grandpaView.center.x = (512.0/1024) * view.frame.width
            grandpaView.center.y = (524.0/1366) * view.frame.height
            
            speechBalloon.frame.size.width = (293.0/1024) * view.frame.width
            speechBalloon.frame.size.height = (265.0 / 1024) * view.frame.width
            speechBalloon.center.x = (492.0/1024) * view.frame.width
            speechBalloon.center.y = (107.0/1366) * view.frame.height
            
            
        }
            ///Portrait
        else {
            
            if countryManager!.mapPhoto! == "PortugalMap" {
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (463.0/1024) * view.frame.width
                city1.center.y = (399.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (564.0/1024) * view.frame.width
                city2.center.y = (437.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (688.0/1024) * view.frame.width
                city3.center.y = (334.0/1366) * view.frame.height
            
            } else if countryManager!.mapPhoto! == "USAMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (295.0/1024) * view.frame.width
                city1.center.y = (390.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (492.0/1024) * view.frame.width
                city2.center.y = (370.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (833.0/1024) * view.frame.width
                city3.center.y = (500.0/1366) * view.frame.height
                
            } else if countryManager!.mapPhoto! == "UKMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (800.0/1024) * view.frame.width
                city1.center.y = (485.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (601.0/1024) * view.frame.width
                city2.center.y = (579.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (466.0/1024) * view.frame.width
                city3.center.y = (696.0/1366) * view.frame.height
                
                
            } else if countryManager!.mapPhoto! == "ItalyMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (431.0/1024) * view.frame.width
                city1.center.y = (362.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (430.0/1024) * view.frame.width
                city2.center.y = (566.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (833.0/1024) * view.frame.width
                city3.center.y = (801.0/1366) * view.frame.height
                
                
            } else if countryManager!.mapPhoto! == "FranceMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (672.0/1024) * view.frame.width
                city1.center.y = (318.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (849.0/1024) * view.frame.width
                city2.center.y = (538.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (494.0/1024) * view.frame.width
                city3.center.y = (684.0/1366) * view.frame.height
                
            } else if countryManager!.mapPhoto! == "EgyptMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (527.0/1024) * view.frame.width
                city1.center.y = (306.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (914.0/1024) * view.frame.width
                city2.center.y = (502.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (413.0/1024) * view.frame.width
                city3.center.y = (619.0/1366) * view.frame.height
                
            } else if countryManager!.mapPhoto! == "BrazilMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (564.0/1024) * view.frame.width
                city1.center.y = (534.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (518.0/1024) * view.frame.width
                city2.center.y = (721.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (417.0/1024) * view.frame.width
                city3.center.y = (772.0/1366) * view.frame.height
                
            } else if countryManager!.mapPhoto! == "IndiaMap"{
                
                city1.frame.size.width = (53.0/1024) * view.frame.width
                city1.frame.size.height = (97.0 / 1024) * view.frame.width
                city1.center.x = (378.0/1024) * view.frame.width
                city1.center.y = (309.0/1366) * view.frame.height
                
                city2.frame.size.width = (53.0/1024) * view.frame.width
                city2.frame.size.height = (97.0 / 1024) * view.frame.width
                city2.center.x = (479.0/1024) * view.frame.width
                city2.center.y = (325.0/1366) * view.frame.height
                
                city3.frame.size.width = (53.0/1024) * view.frame.width
                city3.frame.size.height = (97.0 / 1024) * view.frame.width
                city3.center.x = (199.0/1024) * view.frame.width
                city3.center.y = (513.0/1366) * view.frame.height
                
                
                
            }
            
            
            postcardView.frame.size.width = (1024.0/1024) * view.frame.width
            postcardView.frame.size.height = (712.0 / 1024) * view.frame.width
            postcardView.center.x = (512.0/1024) * view.frame.width
            postcardView.center.y = (741.0/1366) * view.frame.height
            
            closeButton.frame.size.width = (72.0/1024) * view.frame.width
            closeButton.frame.size.height = (72.0 / 1024) * view.frame.width
            closeButton.center.x = (86.0/1024) * view.frame.width
            closeButton.center.y = (500.0/1366) * view.frame.height
            
            grandpaView.frame.size.width = (398.0/1024) * view.frame.width
            grandpaView.frame.size.height = (648.0 / 1024) * view.frame.width
            grandpaView.center.x = (512.0/1024) * view.frame.width
            grandpaView.center.y = (524.0/1366) * view.frame.height
            
            speechBalloon.frame.size.width = (293.0/1024) * view.frame.width
            speechBalloon.frame.size.height = (265.0 / 1024) * view.frame.width
            speechBalloon.center.x = (492.0/1024) * view.frame.width
            speechBalloon.center.y = (107.0/1366) * view.frame.height
            
            
        }
        
        super.viewDidLayoutSubviews()
    }

}

