//
//  CountryManager.swift
//  Swift Traveler
//
//  Created by Nathalia Inacio on 19/03/19.
//  Copyright © 2019 Nathalia Inacio. All rights reserved.
//

import Foundation
import UIKit

public class CountryManager{
    
    
    ///Map View
    public var mapPhoto:String?
    public var pin1 = UIButton()
    public var pin2 = UIButton()
    public var pin3 = UIButton()
    
    public var pin1Color:String?
    public var pin2Color:String?
    public var pin3Color:String?
    
    public var pin1City:String?
    public var pin2City:String?
    public var pin3City:String?
    
    
    
    ///Tourist Attraction View
    public var atrractionName:String?
    
    
    ///Culinary View
    public var flag1Name:String?
    public var flag2Name:String?
    public var flag3Name:String?
    public var nameOfTheCountry:String?
    
    public init(country: String) {
        
   
        
        ///Switch Case
        
        switch country {
        case "USA":
            
            ///Tourist Attraction
            self.atrractionName = "StatueofLiberty"
            
            ///Culinary
            
            self.flag1Name = "USA"
            self.flag2Name = "UK"
            self.flag3Name = "Italy"
            
            ///Map
            mapPhoto = "USAMap"
            
            pin1Color = "LeftPin"
            pin2Color = "RightPin"
            pin3Color = "RightPin"
        
            pin1City = "SanFrancisco"
            pin2City = "Washington"
            pin3City = "NewYork"
            
        case "Portugal":
            
            ///Tourist Attraction
            self.atrractionName = "BelemTower"
        
            
            ///Culinary
            self.flag1Name = "France"
            self.flag2Name = "Portugal"
            self.flag3Name = "UK"
            
            ///Map
            mapPhoto = "PortugalMap"
            
            pin1Color = "RightPin"
            pin2Color = "LeftPin"
            pin3Color = "RightPin"
            
            pin1City = "Lisbon"
            pin2City = "Aveiro"
            pin3City = "Porto"
            
            
        case "UK":
            
            ///Tourist Attraction
            self.atrractionName = "BigBen"
            
            ///Culinary
            self.flag1Name = "India"
            self.flag2Name = "France"
            self.flag3Name = "UK"
            
            ///Map
            mapPhoto = "UKMap"
            
            pin1Color = "RightPin"
            pin2Color = "RightPin"
            pin3Color = "LeftPin"
            
            pin1City = "Edinburgh"
            pin2City = "Liverpool"
            pin3City = "London"
            
            
        case "Italy":
            
            ///Tourist Attraction
            self.atrractionName = "Colosseum"
            
            ///Culinary
            self.flag1Name = "Egypt"
            self.flag2Name = "Brazil"
            self.flag3Name = "Italy"
            
            ///Map
            mapPhoto = "ItalyMap"
            
            pin1Color = "LeftPin"
            pin2Color = "RightPin"
            pin3Color = "RightPin"
            
            pin1City = "Venice"
            pin2City = "Rome"
            pin3City = "Naples"
            
        case "France":
            
            ///Tourist Attraction
            self.atrractionName = "EiffelTower"
            
            ///Culinary
            self.flag1Name = "France"
            self.flag2Name = "Italy"
            self.flag3Name = "USA"
            
            ///Map
            mapPhoto = "FranceMap"
            
            pin1Color = "RightPin"
            pin2Color = "LeftPin"
            pin3Color = "LeftPin"
            
            pin1City = "Paris"
            pin2City = "Lyon"
            pin3City = "Marseille"
            
        case "Egypt":
            
            ///Tourist Attraction
            self.atrractionName = "GizaPyramids"
            
            ///Culinary
            self.flag1Name = "India"
            self.flag2Name = "Brazil"
            self.flag3Name = "Egypt"
            
            ///Map
            mapPhoto = "EgyptMap"
            
            pin1Color = "RightPin"
            pin2Color = "LeftPin"
            pin3Color = "RightPin"

            pin1City = "Cairo"
            pin2City = "Luxor"
            pin3City = "Giza"
            
        case "Brazil":
            
            ///Tourist Attraction
            self.atrractionName = "Redeemer"
            
            ///Culinary
            self.flag1Name = "Portugal"
            self.flag2Name = "Brazil"
            self.flag3Name = "Egypt"
            
            ///Map
            mapPhoto = "BrazilMap"
            
            pin1Color = "LeftPin"
            pin2Color = "RightPin"
            pin3Color = "LeftPin"
  
            pin1City = "Brasilia"
            pin2City = "RiodeJaneiro"
            pin3City = "SaoPaulo"
            
        case "India":
            
            ///Tourist Attraction
            self.atrractionName = "TajMahal"
            
            ///Culinary
            self.flag1Name = "India"
            self.flag2Name = "USA"
            self.flag3Name = "Egypt"
            
            ///Map
            mapPhoto = "IndiaMap"
            
            pin1Color = "RightPin"
            pin2Color = "LeftPin"
            pin3Color = "RightPin"

            pin1City = "NewDelhi"
            pin2City = "Agra"
            pin3City = "Mumbai"
            
        default: break
            
        }
        
        
    }
    
}
