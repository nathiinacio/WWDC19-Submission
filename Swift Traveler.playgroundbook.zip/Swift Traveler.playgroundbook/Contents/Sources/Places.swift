//
//  Places.swift
//  Book_Sources
//
//  Created by Nathalia Inacio on 22/03/19.
//

import Foundation

public enum Places: String {
    case Portugal = "Portugal"
    case Brazil = "Brazil"
    case USA = "USA"
    case France = "France"
    case Italy = "Italy"
    case Egypt = "Egypt"
    case UK = "UK"
    case India = "India"
}
